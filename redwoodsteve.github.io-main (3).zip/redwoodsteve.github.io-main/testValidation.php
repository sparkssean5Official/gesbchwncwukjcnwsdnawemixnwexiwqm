<?php
  echo $_POST["text"];
?>
