A little project I made. Feel free to use the CSS/JavaScript at your will!
