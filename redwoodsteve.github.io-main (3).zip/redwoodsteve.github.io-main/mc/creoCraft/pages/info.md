# CreoCraft info
## Status
CreoCraft is hosted on a computer in my basement, so the server is prone to power outages. <br>
When the server does not have power, it comepletely shuts down, preventing you from joining it before I start it back up.
> The IP for CreoCraft is 'clanders.mynetgear.com' <br>
