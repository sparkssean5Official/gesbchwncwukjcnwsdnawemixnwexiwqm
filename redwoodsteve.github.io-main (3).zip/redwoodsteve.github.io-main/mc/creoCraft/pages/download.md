# Download
---
CreoCraft needs you to download a modpack to play. <br>
###### You need the curseforge desktop app to use the modpack. [Download it here](https://www.curseforge.com/download/app) 
<br>
<a href="modpacks/creoCraft-1.zip" download>Download modpack V1</a>
## Other versions
<a href="modpacks/createBetter-3.0.zip" download>Download old modpack V3</a> <br>
<a href="modpacks/createBetter-2.0.zip" download>Download old modpack V2 (outdated!)</a>
