//any element has to have an ultra version with "u" at the end. There is no need to hard-code the elements in!
var elements = {
    "ruby" : {
        "name": "Ruby",
        "value": 100,  
        "ultra": false
    },
    "rubyu" : {
        "name": "Ruby",
        "value": 200,
        "ultra": true
    },
    "amythyst" : {
        "name": "Amythyst",
        "value": 300,
        "ultra": false
    },
    "amythystu" : {
        "name": "Amythyst",
        "value": 400,
        "ultra": true
    },
    "emerald" : {
        "name": "Emerald",
        "value": 450,
        "ultra": false
    },
    "emeraldu" : {
        "name": "Emerald",
        "value": 530,
        "ultra": true
    },
    "gold": {
        "name": "Gold",
        "value": 600,
        "ultra": false
    },
    "goldu": {
        "name": "Gold",
        "value": 700,
        "ultra": true
    },
}
